import bsInternal
def log(msg,ID):
	for p in bsInternal._getForegroundHostSession().players:
		if p.getInputDevice().getClientID() == int(ID):
			g_id = p.get_account_id()
			name = p.getName().encode("utf-8")
	f = open("log.txt","a")
	f.write(name+"----->"+g_id+"------>"+ msg+"\n")
	f.close()