powerupName = True

powerupShield = False

discoLights = True

#enable true or false. by PCModder, thanks to the the great and for the discoLights
#the distance between you and success is fear.
