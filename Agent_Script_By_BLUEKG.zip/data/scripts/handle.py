import bs
import urllib2
import json
import bsInternal
import random
import time as tim

def getPlayerFromNick(nick):
    nick = bs.uni(nick[:-3] if nick.endswith('...') else nick)
    if '/' in nick:
        nick = nick.split('/')[0]
    if nick.isdigit():
        if len(nick) == 3:
            for i in bsInternal._getForegroundHostActivity().players:
                if str(i.getInputDevice().getClientID()) == nick:
                    return i
        if int(nick) < len(bsInternal._getForegroundHostActivity().players):
            return bsInternal._getForegroundHostActivity().players[int(nick)]
    else:
        for i in bsInternal._getForegroundHostActivity().players:
            if i.getName(True).lower().find(nick.lower()) != -1:
                return i
        else:
            return None
